Product: Laser Cut Cube, September 2014

Designer: Jeremy Baumberg

Support:  http://forums.obrary.com/category/designs/moebius-strip 

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The laser cut cube is designed to be printed on a laser cutter.  It can be made from plywood or acrylic.